package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.modules.module.configuration;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.modules.module.configuration.tsdr.netflow.statistics.collector.RpcRegistry;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.rev130405.modules.module.Configuration;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.modules.module.configuration.tsdr.netflow.statistics.collector.DataBroker;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * <p>This class represents the following YANG schema fragment defined in module <b>tsdr-netflow-statistics-collector</b>
 * <pre>
 * case tsdr-netflow-statistics-collector {
 *     container data-broker {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector?revision=2015-10-11)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 *     container rpc-registry {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector?revision=2015-10-11)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 * }
 * </pre>
 * The schema path to identify an instance is
 * <i>tsdr-netflow-statistics-collector/modules/module/configuration/(urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector?revision=2015-10-11)tsdr-netflow-statistics-collector</i>
 *
 */
public interface TsdrNetflowStatisticsCollector
    extends
    DataObject,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.modules.module.configuration.TsdrNetflowStatisticsCollector>,
    Configuration
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector",
        "2015-10-11", "tsdr-netflow-statistics-collector").intern();

    DataBroker getDataBroker();
    
    RpcRegistry getRpcRegistry();

}

