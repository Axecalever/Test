package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011;
import org.opendaylight.yangtools.yang.binding.DataRoot;


/**
 * This module contains the base YANG definitions for 
 * tsdr-netflow-statistics-collector impl implementation.
 *
 * <p>This class represents the following YANG schema fragment defined in module <b>tsdr-netflow-statistics-collector</b>
 * <pre>
 * module tsdr-netflow-statistics-collector {
 *     yang-version 1;
 *     namespace "urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector";
 *     prefix "tsdr-netflow-statistics-collector";
 *
 *     import opendaylight-md-sal-binding { prefix "mdsal"; }
 *     
 *     import config { prefix "config"; }
 *     revision 2015-10-11 {
 *         description "This module contains the base YANG definitions for 
 *                     tsdr-netflow-statistics-collector impl implementation.
 *         ";
 *     }
 *
 *     container TSDRNetFlowConfig {
 *         leaf polling-interval {
 *             type int64;
 *         }
 *     }
 *
 *     augment \(urn:opendaylight:params:xml:ns:yang:controller:config)modules\(urn:opendaylight:params:xml:ns:yang:controller:config)module\(urn:opendaylight:params:xml:ns:yang:controller:config)configuration {
 *         status CURRENT;
 *         case tsdr-netflow-statistics-collector {
 *             container data-broker {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector?revision=2015-10-11)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *             container rpc-registry {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector?revision=2015-10-11)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *         }
 *     }
 *
 *     identity tsdr-netflow-statistics-collector {
 *         base "()IdentityEffectiveStatementImpl[base=null, qname=(urn:opendaylight:params:xml:ns:yang:controller:config?revision=2013-04-05)module-type]";
 *         status CURRENT;
 *     }
 *
 *     rpc setPollingInterval {
 *         "set the polling interval of the collector";
 *         input {
 *             leaf interval {
 *                 type int64;
 *             }
 *         }
 *         
 *     }
 * }
 * </pre>
 *
 */
public interface TsdrNetflowStatisticsCollectorData
    extends
    DataRoot
{




    TSDRNetFlowConfig getTSDRNetFlowConfig();

}

