package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011;
import org.opendaylight.yangtools.yang.binding.RpcService;
import org.opendaylight.yangtools.yang.common.RpcResult;
import java.util.concurrent.Future;


/**
 * Interface for implementing the following YANG RPCs defined in module <b>tsdr-netflow-statistics-collector</b>
 * <pre>
 * rpc setPollingInterval {
 *     "set the polling interval of the collector";
 *     input {
 *         leaf interval {
 *             type int64;
 *         }
 *     }
 *     
 * }
 * </pre>
 *
 */
public interface TsdrNetflowStatisticsCollectorService
    extends
    RpcService
{




    /**
     * set the polling interval of the collector
     *
     */
    Future<RpcResult<java.lang.Void>> setPollingInterval(SetPollingIntervalInput input);

}

