package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.rev130405.ModuleType;
import org.opendaylight.yangtools.yang.common.QName;


/**
 * <p>This class represents the following YANG schema fragment defined in module <b>tsdr-netflow-statistics-collector</b>
 * <pre>
 * identity tsdr-netflow-statistics-collector {
 *     base "()IdentityEffectiveStatementImpl[base=null, qname=(urn:opendaylight:params:xml:ns:yang:controller:config?revision=2013-04-05)module-type]";
 *     status CURRENT;
 * }
 * </pre>
 * The schema path to identify an instance is
 * <i>tsdr-netflow-statistics-collector/tsdr-netflow-statistics-collector</i>
 *
 */
public abstract class TsdrNetflowStatisticsCollector extends ModuleType
 {
    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector",
        "2015-10-11", "tsdr-netflow-statistics-collector").intern();


    public TsdrNetflowStatisticsCollector() {
    
    
    }
    






}

