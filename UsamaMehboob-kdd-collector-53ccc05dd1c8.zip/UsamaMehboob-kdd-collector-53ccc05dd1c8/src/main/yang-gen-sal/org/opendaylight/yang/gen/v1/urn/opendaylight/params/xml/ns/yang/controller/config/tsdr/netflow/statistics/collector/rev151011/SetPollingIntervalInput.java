package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * <p>This class represents the following YANG schema fragment defined in module <b>tsdr-netflow-statistics-collector</b>
 * <pre>
 * container input {
 *     leaf interval {
 *         type int64;
 *     }
 * }
 * </pre>
 * The schema path to identify an instance is
 * <i>tsdr-netflow-statistics-collector/setPollingInterval/input</i>
 *
 * <p>To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.SetPollingIntervalInputBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.SetPollingIntervalInputBuilder
 *
 */
public interface SetPollingIntervalInput
    extends
    DataObject,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.netflow.statistics.collector.rev151011.SetPollingIntervalInput>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:params:xml:ns:yang:controller:config:tsdr:netflow:statistics:collector",
        "2015-10-11", "input").intern();

    /**
     * interval
     *
     */
    java.lang.Long getInterval();

}

