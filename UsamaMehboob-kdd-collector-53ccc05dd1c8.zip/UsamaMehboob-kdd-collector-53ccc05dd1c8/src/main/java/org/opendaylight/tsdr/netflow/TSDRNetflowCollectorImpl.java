/*
 * Copyright (c) 2015 Cisco Systems, Inc. and others.  All rights reserved.
 * Copyright (c) 2015 xFlow Research Inc. and others, All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.tsdr.netflow;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
////////////////////////
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.sql.Statement;
///////////////////////

import org.opendaylight.yang.gen.v1.opendaylight.tsdr.rev150219.DataCategory;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.collector.spi.rev150915.InsertTSDRLogRecordInputBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.collector.spi.rev150915.TsdrCollectorSpiService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.collector.spi.rev150915.inserttsdrlogrecord.input.TSDRLogRecord;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.tsdr.collector.spi.rev150915.inserttsdrlogrecord.input.TSDRLogRecordBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NetFlow Collector to receive netflow packets and store into TSDR data store.
 *
 * Currently only NetFlow Version 5 is supported.
 *
 * @author <a href="mailto:yuling_c@dell.com">YuLing Chen</a>
 * @author <a href="mailto:muhammad.umair@xflowresearch.com">Umair Bhatti</a>
 * @author <a href="mailto:saichler@xgmail.com">Sharon Aicler</a>
 *
 * Created: December 1, 2015
 * Modified: Feb 8, 2016
 */
public class TSDRNetflowCollectorImpl extends Thread{

    private static final long PERSIST_CHECK_INTERVAL_IN_MILLISECONDS = 5000;
    private static final long INCOMING_QUEUE_WAIT_INTERVAL_IN_MILLISECONDS = 2000;
    private static final int FLOW_SIZE_FOR_NETFLOW_PACKET = 48;
    private static final Logger logger = LoggerFactory.getLogger(TSDRNetflowCollectorImpl.class);
    private final TsdrCollectorSpiService collectorSPIService;
    private boolean running = true;
    private final LinkedList<DatagramPacket> incomingNetFlow = new LinkedList<>();
    private long lastPersisted = System.currentTimeMillis();
    private long lastTimeStamp = System.currentTimeMillis();
    /**
     * Constructor
     * @param _collectorSPIService
     */
    public TSDRNetflowCollectorImpl(TsdrCollectorSpiService _collectorSPIService) throws IOException{
        super("Kdd-Data-Set-Collector");
        this.setDaemon(true);
        this.collectorSPIService = _collectorSPIService;
        this.start();
        logger.debug("kdd-Data-Set-Collector Thread initialized");
        //new NetFlowProcessor();
    }
    public void run(){
            LinkedList<TSDRLogRecord> netFlowQueue = new LinkedList<TSDRLogRecord>();
            Scanner scanner = null;
			try {
				scanner = new Scanner(new File(this.getClass().getResource( "/kdd_10_unlabel2.csv" ).toURI() ));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            int recordCounter=1;
            while (running && scanner.hasNext()) {
                long currentTimeStamp = System.currentTimeMillis();
                String comSeparatedStrLine=scanner.nextLine();
                TSDRLogRecordBuilder recordbuilder = new TSDRLogRecordBuilder();
                NetflowPacketParser parser = new NetflowPacketParser(comSeparatedStrLine);
                        /*Fill up the RecordBuilder object*/
                recordbuilder.setNodeID("127.0.0.1");
                recordbuilder.setTimeStamp(currentTimeStamp);
                recordbuilder.setIndex(recordCounter);
                recordbuilder.setTSDRDataCategory(DataCategory.KDD99SET);
                recordbuilder.setRecordFullText(parser.toString());
                if(logger.isDebugEnabled()) {
                    logger.debug(parser.toString());
                }
                recordbuilder.setRecordAttributes(parser.getRecordAttributes());
                TSDRLogRecord logRecord =  recordbuilder.build();
                if(logRecord!=null){
                    netFlowQueue.add(logRecord);
                }
                recordCounter += 1;
                if(System.currentTimeMillis()-lastPersisted>PERSIST_CHECK_INTERVAL_IN_MILLISECONDS && !netFlowQueue.isEmpty()){
                    LinkedList<TSDRLogRecord> queue = null;
                    lastPersisted = System.currentTimeMillis();
                    queue = netFlowQueue;
                    netFlowQueue = new LinkedList<TSDRLogRecord>();
                    if(queue!=null){
                        store(queue);
                    }                
                }
                
            }
    }

    public void shutdown(){
        running = false;
    }
                    
   /**
     * Store the data into TSDR data store
     * @param queue
     */
    private void store(List<TSDRLogRecord> queue){
        InsertTSDRLogRecordInputBuilder input = new InsertTSDRLogRecordInputBuilder();
        input.setTSDRLogRecord(queue);
        input.setCollectorCodeName("TSDRNetFlowCollector");
        collectorSPIService.insertTSDRLogRecord(input.build());
    }
}
