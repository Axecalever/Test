/*
 * Copyright (c) 2015 Cisco Systems, Inc. and others.  All rights reserved.
 * Copyright (c) 2015 xFlow Research Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.tsdr.netflow;

import org.opendaylight.yang.gen.v1.opendaylight.tsdr.log.data.rev160325.tsdrlog.RecordAttributes;
import org.opendaylight.yang.gen.v1.opendaylight.tsdr.log.data.rev160325.tsdrlog.RecordAttributesBuilder;
import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:saichler@gmail.com">Sharon Aicler</a>
 * @author <a href="mailto:muhammad.umair@xflowresearch.com">Umair Bhatti</a>
 *
 * Modified: Feb 08, 2016
 */
public class NetflowPacketParser {

    private final List<RecordAttributes> recordAttributes = new ArrayList<>(10);

    /*
     * Constructor just make the header for netflow packet. There could be multiple PDU's of which the header would be same.
     */

    /////////////////////
    static int duration = 0, protocol_type =1 ,service =2,flag =3,src_bytes=4,
    dst_bytes =5,land=6, wrong_fragment=7,urgent=8,hot=9,num_failed_logins=10,logged_in=11,
    num_compromised=12,root_shell=13,su_attempted=14,num_root=15,
    num_file_creations=16,num_shells=17,num_access_files=18,
    num_outbound_cmds=19,is_host_login=20,is_guest_login=21,
    count=22,srv_count=23,serror_rate=24,srv_serror_rate=25,rerror_rate=26,
    srv_rerror_rate=27,same_srv_rate=28,diff_srv_rate=29,srv_diff_host_rate=30,dst_host_count=31,
    dst_host_srv_count=32,dst_host_same_srv_rate=33,
    dst_host_diff_srv_rate=34,  dst_host_same_src_port_rate=35,
    dst_host_srv_diff_host_rate=36,dst_host_serror_rate=37,
    dst_host_srv_serror_rate=38,dst_host_rerror_rate=39,dst_host_srv_rerror_rate=40;
    /////////////////////

    public NetflowPacketParser(String CsvLine){
        String[] rowFeatures=CsvLine.split(",");
        addValue("duration",rowFeatures[duration]);
        addValue("protocolType",rowFeatures[protocol_type]);
        addValue("service",rowFeatures[service]);
        addValue("flag",rowFeatures[flag]);
        addValue("sourceBytes",rowFeatures[src_bytes]);
        addValue("destBytes",rowFeatures[dst_bytes]);
        addValue("land",rowFeatures[land]);
        addValue("wrongFragment",rowFeatures[wrong_fragment]);
        addValue("urgent",rowFeatures[urgent]);
        addValue("hot",rowFeatures[hot]);
    }
    
    public List<RecordAttributes> getRecordAttributes(){
        return this.recordAttributes;
    }

    public void addValue(String name,String value){
        RecordAttributesBuilder builder = new RecordAttributesBuilder();
        builder.setName(name);
        builder.setValue(value);
        this.recordAttributes.add(builder.build());
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for(RecordAttributes ra:this.recordAttributes){
            if(!first){
                sb.append(",");
            }
            sb.append(ra.getName());
            sb.append("=");
            sb.append(ra.getValue());
            first = false;
        }
        return sb.toString();
    }
}
